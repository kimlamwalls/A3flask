def setup_music():
    return None
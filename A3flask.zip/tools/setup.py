import tools

try:
    tools.delete_music_table()
except:
    print('table not found, attempting to continue')

tools.store_studentid_users()

tools.create_and_populate_music_table()

tools.download_images_from_json('a2.json')

tools.upload_images_from_folder('img/', 's3917984')

tools.update_img_urls()